package devandroid.maruzam.appgaseta.controller;

import android.content.ContentValues;
import android.content.SharedPreferences;

import devandroid.maruzam.appgaseta.database.GasEtaDB;
import devandroid.maruzam.appgaseta.model.Combustivel;
import devandroid.maruzam.appgaseta.view.GasEtaActivity;

public class CombustivelController extends GasEtaDB {

    SharedPreferences preferences;
    SharedPreferences.Editor dadosPreferences;
    public static final String NOME_PREFERENCES = "pref_gaseta";

    public CombustivelController(GasEtaActivity activity) {
        super(activity);

        preferences = activity.getSharedPreferences(NOME_PREFERENCES, 0);
        dadosPreferences = preferences.edit();

    }

    public void salvar(Combustivel combustivel) {

        ContentValues dados = new ContentValues();

        dadosPreferences.putString("combustivel", combustivel.getNomeCombustivel());
        dadosPreferences.putFloat("precoCombustivel", (float) combustivel.getPrecoCombustivel());
        dadosPreferences.putString("recomendacao", combustivel.getRecomendacao());
        dadosPreferences.apply();

        dados.put("nomeCombustivel", combustivel.getNomeCombustivel());
        dados.put("precoCombustivel", combustivel.getPrecoCombustivel());
        dados.put("recomendacao", combustivel.getRecomendacao());




        salvarObjeto("Combustivel", dados);


    }

    public void limpar() {

        dadosPreferences.clear();
        dadosPreferences.apply();
    }
}
